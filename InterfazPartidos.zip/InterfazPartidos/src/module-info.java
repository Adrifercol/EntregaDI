module InterfazPartidos {
    requires javafx.controls;
    requires javafx.graphics;
    exports logica;
    exports models;
    exports vistas;
}